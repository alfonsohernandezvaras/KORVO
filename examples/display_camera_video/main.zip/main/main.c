/*
 * SPDX-FileCopyrightText: 2025-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

/**
 * @file
 * @brief BSP Camera Example
 * @details Stream camera output to display (LVGL)
 * @example https://espressif.github.io/esp-launchpad/?flashConfigURL=https://espressif.github.io/esp-bsp/config.toml&app=display_camera_video
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "sdkconfig.h"
#include "bsp/esp-bsp.h"
#include "esp_err.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_attr.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#if SOC_PPA_SUPPORTED
#include "driver/ppa.h"
#endif
#include "esp_private/esp_cache_private.h"
#include "app_video.h"
#include "face_detect.h"
#include "korvo_hmi.h"
#include "korvo_storage.h"
#include "korvo_network.h"
#include "korvo_web.h"
#include "korvo_update.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

#define NUM_BUFS 2
#define ALIGN_UP(num, align)    (((num) + ((align) - 1)) & ~((align) - 1))

typedef struct {
    void  *start;
    size_t length;
} mmap_buf_t;

static const char *TAG = "example";

#if SOC_PPA_SUPPORTED
static ppa_client_handle_t ppa_srm_handle = NULL;
#endif
static size_t data_cache_line_size = 0;
static lv_obj_t *camera_canvas = NULL;
static uint8_t *cam_buff[NUM_BUFS];
static uint32_t cam_buff_size = 0;

static lv_color_format_t lvgl_cam_rgb565_fmt;

/* ===== FACE DETECTION ===== */
#define FACE_DETECT_EVERY_N_FRAMES 5
#define CAMERA_START_RETRIES        5
#define VIDEO_OPEN_RETRIES          10

static uint8_t *face_ai_buffer = NULL;
static size_t face_ai_buffer_size = 0;
static SemaphoreHandle_t face_ai_mutex = NULL;
static volatile bool face_ai_pending = false;
static uint32_t face_frame_counter = 0;
static uint16_t face_ai_width = 0;
static uint16_t face_ai_height = 0;

/* ===== KORVO PRESENCE / WAKE STATE ===== */
#define FACE_LOST_SLEEP_MS              10000

/*
 * LCD activity timer:
 * - starts once when a candidate wakes the screen
 * - is refreshed ONLY by a face that passes the HMI geometry matrix
 *
 * Repeated ESP-DL false positives therefore cannot keep the LCD on forever.
 */
static TickType_t last_face_tick = 0;
static bool korvo_awake = false;

/* ===== CAMERA MOTION DIAGNOSTIC =====
 * Lightweight sampled RGB565 frame difference. This is independent from
 * ESP-DL face detection and runs directly in the existing frame callback.
 */
#define MOTION_SAMPLE_STEP_PIXELS   16
#define MOTION_PIXEL_DELTA          18
#define MOTION_ACTIVE_PERCENT_X10   180  /* 18.0% candidate */
#define MOTION_STRONG_PERCENT_X10   300  /* 30.0% = immediate real motion */
#define MOTION_WAKE_PERCENT_X10     180  /* candidate threshold */
#define MOTION_IDLE_SLEEP_MS        10000
#define MOTION_CONFIRM_SAMPLES      3    /* 18-30% must persist */
#define MOTION_CLEAR_SAMPLES        6    /* <18% must persist before inactive */

static volatile uint32_t motion_percent_x10 = 0;
static volatile bool motion_active = false;
static volatile TickType_t last_motion_tick = 0;
static uint16_t *motion_reference = NULL;
static size_t motion_reference_count = 0;
static uint32_t motion_frame_counter = 0;

/*
 * Boot sequencing:
 * First bring up display + camera + video and leave the camera visible.
 * Auxiliary services (motion/screensaver + ESP-DL face AI) are enabled
 * only 10 seconds after KORVO READY.
 */
#define KORVO_SERVICES_START_DELAY_MS 10000
#define CAMERA_HEALTH_TIMEOUT_MS       8000
#define CAMERA_HEALTH_VALID_SAMPLES    3
#define CAMERA_RUNTIME_WATCHDOG_TIMEOUT_MS 10000
#define CAMERA_RUNTIME_WATCHDOG_POLL_MS     1000

/* Independent SD watchdog: read-only probe every 5 seconds. */
#define STORAGE_WATCHDOG_POLL_MS             5000

static volatile bool korvo_services_enabled = false;
static volatile uint32_t camera_health_valid_samples = 0;
static volatile TickType_t camera_last_valid_frame_tick = 0;
static volatile bool camera_runtime_watchdog_enabled = false;
static uint8_t motion_confirm_count = 0;
static uint8_t motion_clear_count = 0;

static lv_color_format_t lvgl_rgb565_fmt_from_v4l2(uint32_t pixelformat)
{
    if (pixelformat == V4L2_PIX_FMT_RGB565X) {
        return LV_COLOR_FORMAT_RGB565_SWAPPED;
    }
    if (pixelformat == V4L2_PIX_FMT_RGB565) {
        return LV_COLOR_FORMAT_RGB565;
    }
    ESP_LOGW(TAG, "Unexpected RGB565 pixel format, using LV_COLOR_FORMAT_RGB565");
    return LV_COLOR_FORMAT_RGB565;
}

#if SOC_PPA_SUPPORTED
static void app_ppa_init(void)
{
    /* Initialize PPA */
    ppa_client_config_t ppa_srm_config = {
        .oper_type = PPA_OPERATION_SRM,
    };

    esp_err_t ret = ppa_register_client(&ppa_srm_config, &ppa_srm_handle);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to register PPA client: 0x%x", ret);
    }
}

static esp_err_t app_image_process_scale_crop(
    uint8_t *in_buf, uint32_t in_width, uint32_t in_height,
    uint8_t *out_buf, uint32_t out_width, uint32_t out_height, size_t out_buf_size,
    ppa_srm_rotation_angle_t rotation_angle)
{
    float scale_x = (float)out_width / in_width;
    float scale_y = (float)out_height / in_height;

    if (rotation_angle == PPA_SRM_ROTATION_ANGLE_90 || rotation_angle == PPA_SRM_ROTATION_ANGLE_270) {
        scale_x = (float)out_height / in_width;
        scale_y = (float)out_width / in_height;
    }

    ppa_srm_oper_config_t srm_config = {
        .in.buffer = in_buf,
        .in.pic_w = in_width,
        .in.pic_h = in_height,
        .in.block_w = in_width,
        .in.block_h = in_height,
        .in.block_offset_x = 0,
        .in.block_offset_y = 0,
        .in.srm_cm = PPA_SRM_COLOR_MODE_RGB565,
        .out.buffer = out_buf,
        .out.buffer_size = out_buf_size,
        .out.pic_w = out_width,
        .out.pic_h = out_height,
        .out.block_offset_x = 0,
        .out.block_offset_y = 0,
        .out.srm_cm = PPA_SRM_COLOR_MODE_RGB565,
        .rotation_angle = rotation_angle,
        .scale_x = scale_x,
        .scale_y = scale_y,
        .rgb_swap = 0,
        .byte_swap = 0,
        .mode = PPA_TRANS_MODE_BLOCKING,
    };

    return ppa_do_scale_rotate_mirror(ppa_srm_handle, &srm_config);
}

static void calc_aspect_fit(
    uint32_t src_w, uint32_t src_h,
    uint32_t dst_w, uint32_t dst_h,
    uint32_t *out_w, uint32_t *out_h)
{
    float src_aspect = (float)src_w / src_h;
    float dst_aspect = (float)dst_w / dst_h;

    if (src_aspect > dst_aspect) {
        *out_w = dst_w;
        *out_h = dst_w / src_aspect;
    } else {
        *out_h = dst_h;
        *out_w = dst_h * src_aspect;
    }
}
#endif

static void motion_process_rgb565(const uint8_t *camera_buf,
                                  uint32_t width,
                                  uint32_t height,
                                  size_t camera_buf_len)
{
    /* Camera health runs during boot, but HMI/screensaver effects do not. */
    if (camera_buf == NULL || width == 0 || height == 0) {
        return;
    }

    size_t pixels = (size_t)width * height;
    if (camera_buf_len < pixels * 2U) {
        return;
    }

    const uint16_t *src = (const uint16_t *)camera_buf;

    size_t samples_x = (width + MOTION_SAMPLE_STEP_PIXELS - 1) /
                       MOTION_SAMPLE_STEP_PIXELS;
    size_t samples_y = (height + MOTION_SAMPLE_STEP_PIXELS - 1) /
                       MOTION_SAMPLE_STEP_PIXELS;
    size_t needed = samples_x * samples_y;

    if (motion_reference == NULL || motion_reference_count != needed) {
        free(motion_reference);
        motion_reference = heap_caps_malloc(needed * sizeof(uint16_t),
                                            MALLOC_CAP_SPIRAM);
        if (motion_reference == NULL) {
            motion_reference_count = 0;
            return;
        }
        motion_reference_count = needed;

        size_t k = 0;
        for (uint32_t y = 0; y < height; y += MOTION_SAMPLE_STEP_PIXELS) {
            for (uint32_t x = 0; x < width; x += MOTION_SAMPLE_STEP_PIXELS) {
                motion_reference[k++] = src[(size_t)y * width + x];
            }
        }
        last_motion_tick = xTaskGetTickCount();
        return;
    }

    size_t changed = 0;
    size_t total = 0;
    size_t k = 0;

    for (uint32_t y = 0; y < height; y += MOTION_SAMPLE_STEP_PIXELS) {
        for (uint32_t x = 0; x < width; x += MOTION_SAMPLE_STEP_PIXELS) {
            uint16_t now = src[(size_t)y * width + x];
            uint16_t prev = motion_reference[k];

            int nr = (now >> 11) & 0x1F;
            int ng = (now >> 5) & 0x3F;
            int nb = now & 0x1F;
            int pr = (prev >> 11) & 0x1F;
            int pg = (prev >> 5) & 0x3F;
            int pb = prev & 0x1F;

            int delta = abs(nr - pr) * 2 +
                        abs(ng - pg) +
                        abs(nb - pb) * 2;

            if (delta >= MOTION_PIXEL_DELTA) {
                changed++;
            }

            /* Slowly follow the scene by using the current sampled frame
             * as the next reference. */
            motion_reference[k] = now;
            k++;
            total++;
        }
    }

    if (total == 0) {
        return;
    }

    motion_percent_x10 = (uint32_t)((changed * 1000U) / total);

    /* A computed percentage, including 0.0%, proves real RGB565 processing.
     * It is also the permanent camera heartbeat.
     */
    camera_last_valid_frame_tick = xTaskGetTickCount();

    if (camera_health_valid_samples < CAMERA_HEALTH_VALID_SAMPLES) {
        camera_health_valid_samples++;
    }

    /* During boot calculate health only; no motion/HMI/screensaver effects. */
    if (!korvo_services_enabled) {
        return;
    }

    /*
     * Stage 5.2 motion filter:
     *   >=30% : strong movement, accept immediately.
     *   18-30%: candidate movement, require consecutive samples.
     *   <18%  : require consecutive quiet samples before clearing motion.
     *
     * This prevents isolated LCD/light flicker spikes from continuously
     * resetting the inactivity timer.
     */
    bool motion_event = false;

    if (motion_percent_x10 >= MOTION_STRONG_PERCENT_X10) {
        motion_confirm_count = MOTION_CONFIRM_SAMPLES;
        motion_clear_count = 0;
        motion_active = true;
        motion_event = true;
    } else if (motion_percent_x10 >= MOTION_ACTIVE_PERCENT_X10) {
        motion_clear_count = 0;
        if (motion_confirm_count < MOTION_CONFIRM_SAMPLES) {
            motion_confirm_count++;
        }
        if (motion_confirm_count >= MOTION_CONFIRM_SAMPLES) {
            motion_active = true;
            motion_event = true;
        }
    } else {
        motion_confirm_count = 0;
        if (motion_clear_count < MOTION_CLEAR_SAMPLES) {
            motion_clear_count++;
        }
        if (motion_clear_count >= MOTION_CLEAR_SAMPLES) {
            motion_active = false;
        }
    }

    TickType_t now_tick = xTaskGetTickCount();
    if (motion_event) {
        last_motion_tick = now_tick;
    }

    /*
     * Strong scene motion can wake the LCD even before ESP-DL finds a face.
     * It does NOT imply a face or authorization.
     */
    /*
     * Wake the visual HMI ONLY on strong real motion (>=30%).
     * The 18-30% band remains filtered for diagnostics/activity, but it cannot
     * remove the black screensaver.
     */
    if (!korvo_awake && motion_percent_x10 >= MOTION_STRONG_PERCENT_X10) {
        korvo_awake = true;
        last_face_tick = now_tick;
        korvo_hmi_wake();
    }

    /*
     * Temporary diagnostic overlay requested for calibration.
     */
    uint32_t idle_ms = 0;
    if (last_motion_tick != 0) {
        idle_ms = (uint32_t)((now_tick - last_motion_tick) * portTICK_PERIOD_MS);
    }
    if (idle_ms > MOTION_IDLE_SLEEP_MS) {
        idle_ms = MOTION_IDLE_SLEEP_MS;
    }

    korvo_hmi_update_motion(motion_percent_x10,
                            motion_active,
                            idle_ms,
                            MOTION_IDLE_SLEEP_MS);

    /*
     * Actual display sleep is based on real camera inactivity.
     * ESP-DL false positives no longer prevent standby.
     */
    /*
     * IMPORTANT:
     * Do not gate standby with korvo_awake. The diagnostic countdown is
     * authoritative: once real camera inactivity reaches 10 s, force the
     * software screensaver ON. This also self-corrects any HMI/awake state mismatch.
     */
    if (last_motion_tick != 0 &&
        (now_tick - last_motion_tick) >= pdMS_TO_TICKS(MOTION_IDLE_SLEEP_MS)) {
        korvo_awake = false;
        korvo_hmi_no_face();
        korvo_hmi_sleep();
    }
}

static void face_detection_task(void *arg)
{
    ESP_LOGI(TAG, "Starting ESP-DL face detector");

    if (!face_detect_init()) {
        ESP_LOGE(TAG, "Failed to initialize face detector");
        vTaskDelete(NULL);
        return;
    }

    ESP_LOGI(TAG, "ESP-DL face detector ready");

    while (1) {
        if (!face_ai_pending) {
            /*
             * The sleep timeout must run independently from ESP-DL results.
             * This prevents a stale READY message from remaining forever.
             */
            if (korvo_awake &&
                last_face_tick != 0 &&
                (xTaskGetTickCount() - last_face_tick) >= pdMS_TO_TICKS(FACE_LOST_SLEEP_MS)) {
                /* LCD standby is owned by motion_process_rgb565(). */
                korvo_hmi_no_face();
            }

            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }

        face_detection_t result = {0};

        if (xSemaphoreTake(face_ai_mutex, portMAX_DELAY) == pdTRUE) {
            bool ok = face_detect_run(face_ai_buffer,
                                      face_ai_width,
                                      face_ai_height,
                                      &result);
            face_ai_pending = false;
            xSemaphoreGive(face_ai_mutex);

            if (!ok) {
                ESP_LOGW(TAG, "Face detector run failed");
                continue;
            }
        }

        TickType_t now = xTaskGetTickCount();

        if (result.detected) {
            ESP_LOGI(TAG, "FACE score=%.3f box=[%d,%d,%d,%d]",
                     result.score, result.x1, result.y1,
                     result.x2, result.y2);

            /*
             * Any ESP-DL candidate may wake the LCD, but it starts the
             * 10-second activity window only once. Repeated false positives
             * must NOT refresh this timer.
             */
            /*
             * LCD wake/sleep is controlled exclusively by the real motion
             * detector. ESP-DL may classify/track a face, but a false-positive
             * face must never wake the LCD again after motion timeout.
             */
            korvo_hmi_track_face(&result, face_ai_width, face_ai_height);
            korvo_hmi_update_face(&result, face_ai_width, face_ai_height);

            /*
             * Refresh LCD activity only after the candidate passes the
             * geometric face matrix. POSITION means ESP-DL saw something,
             * but it is not yet a usable/credible face for this purpose.
             */
            korvo_hmi_face_state_t face_state = korvo_hmi_face_state();
            if (face_state == KORVO_HMI_FACE_HOLD_STILL ||
                face_state == KORVO_HMI_FACE_READY) {
                last_face_tick = now;
            }

            /*
             * Check timeout here too. This is essential when ESP-DL keeps
             * returning detected=true for a ceiling/object false positive.
             */
            if (korvo_awake &&
                last_face_tick != 0 &&
                (now - last_face_tick) >= pdMS_TO_TICKS(FACE_LOST_SLEEP_MS)) {
                /* LCD standby is owned by motion_process_rgb565(). */
                korvo_hmi_no_face();
            }
        } else {
            /*
             * Immediately clear READY/stability when the face disappears.
             * Keep the LCD awake for FACE_LOST_SLEEP_MS so the user can
             * reposition without the screen flashing off.
             */
            korvo_hmi_no_face();

            if (korvo_awake &&
                last_face_tick != 0 &&
                (now - last_face_tick) >= pdMS_TO_TICKS(FACE_LOST_SLEEP_MS)) {
                /* LCD standby is owned by motion_process_rgb565(). */
            }
        }
    }
}

static void camera_video_frame_operation(uint8_t *camera_buf, uint8_t camera_buf_index, uint32_t camera_buf_hes,
        uint32_t camera_buf_ves, size_t camera_buf_len)
{
    uint32_t out_w = camera_buf_hes;
    uint32_t out_h = camera_buf_ves ;
    uint8_t *out_buf = camera_buf;

    /*
     * Lightweight motion sampling runs independently from ESP-DL.
     * Use every 3rd video frame to keep callback cost low.
     */
    motion_frame_counter++;
    if ((motion_frame_counter % 3U) == 0U) {
        motion_process_rgb565(camera_buf,
                              camera_buf_hes,
                              camera_buf_ves,
                              camera_buf_len);
    }

    /*
     * Copy a periodic camera frame into a dedicated PSRAM buffer.
     * ESP-DL runs in its own task, never inside this video callback.
     */
    face_frame_counter++;
    if (face_ai_buffer != NULL &&
        face_ai_mutex != NULL &&
        !face_ai_pending &&
        (face_frame_counter % FACE_DETECT_EVERY_N_FRAMES) == 0) {

        size_t required = (size_t)camera_buf_hes * camera_buf_ves * 2;

        if (required <= face_ai_buffer_size &&
            required <= camera_buf_len &&
            xSemaphoreTake(face_ai_mutex, 0) == pdTRUE) {

            memcpy(face_ai_buffer, camera_buf, required);
            face_ai_width = (uint16_t)camera_buf_hes;
            face_ai_height = (uint16_t)camera_buf_ves;
            face_ai_pending = true;

            xSemaphoreGive(face_ai_mutex);
        }
    }
#if SOC_PPA_SUPPORTED
    ppa_srm_rotation_angle_t rotation = PPA_SRM_ROTATION_ANGLE_0;

    switch (BSP_CAMERA_ROTATION) {
    case 0:
        rotation = PPA_SRM_ROTATION_ANGLE_0;
        break;
    case 90:
        rotation = PPA_SRM_ROTATION_ANGLE_90;
        break;
    case 180:
        rotation = PPA_SRM_ROTATION_ANGLE_180;
        break;
    case 270:
        rotation = PPA_SRM_ROTATION_ANGLE_270;
        break;
    }

    /* Get size of camera for screen (by aspect ratio)  */
    if (BSP_CAMERA_ROTATION == 90 || BSP_CAMERA_ROTATION == 270) {
        calc_aspect_fit(camera_buf_ves, camera_buf_hes, BSP_LCD_H_RES, BSP_LCD_V_RES, &out_w, &out_h);
    } else {
        calc_aspect_fit(camera_buf_hes, camera_buf_ves, BSP_LCD_H_RES, BSP_LCD_V_RES, &out_w, &out_h);
    }

    /* Scale camera picture for the screen + rotation */
    app_image_process_scale_crop(
        camera_buf, camera_buf_hes, camera_buf_ves,
        cam_buff[camera_buf_index], out_w, out_h, cam_buff_size,
        rotation
    );
    out_buf = cam_buff[camera_buf_index];
#endif

    bsp_display_lock(0);
    lv_canvas_set_buffer(camera_canvas, out_buf, out_w, out_h, lvgl_cam_rgb565_fmt);
    lv_obj_center(camera_canvas);
    lv_obj_invalidate(camera_canvas);
    bsp_display_unlock();
}


static void camera_runtime_watchdog_task(void *arg)
{
    ESP_LOGI(TAG, "CAMERA RUNTIME WATCHDOG started: timeout=%d ms",
             CAMERA_RUNTIME_WATCHDOG_TIMEOUT_MS);

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(CAMERA_RUNTIME_WATCHDOG_POLL_MS));

        if (!camera_runtime_watchdog_enabled) {
            continue;
        }

        TickType_t last = camera_last_valid_frame_tick;
        TickType_t now = xTaskGetTickCount();

        if (last == 0) {
            continue;
        }

        uint32_t age_ms = (uint32_t)((now - last) * portTICK_PERIOD_MS);
        if (age_ms >= CAMERA_RUNTIME_WATCHDOG_TIMEOUT_MS) {
            ESP_LOGE(TAG,
                     "CAMERA RUNTIME WATCHDOG TIMEOUT - no valid RGB565 processing for %lu ms - restarting",
                     (unsigned long)age_ms);
            vTaskDelay(pdMS_TO_TICKS(250));
            esp_restart();
        }
    }
}



static void storage_watchdog_task(void *arg)
{
    bool last_ok = false;
    bool first_sample = true;

    ESP_LOGI(TAG, "SD WATCHDOG started: poll=%d ms",
             STORAGE_WATCHDOG_POLL_MS);

    while (1) {
        korvo_storage_status_t status = {0};
        esp_err_t err = korvo_storage_get_status(&status);
        bool ok = (err == ESP_OK && status.ok);

        korvo_hmi_update_storage(status.sd_ok,
                                 status.fs_ok,
                                 status.structure_ok,
                                 (int)status.state,
                                 status.used_bytes,
                                 status.free_bytes);

        if (first_sample || ok != last_ok) {
            if (ok) {
                ESP_LOGI(TAG,
                         "SD WATCHDOG: OK used=%llu MB free=%llu MB",
                         (unsigned long long)(status.used_bytes / (1024ULL * 1024ULL)),
                         (unsigned long long)(status.free_bytes / (1024ULL * 1024ULL)));
            } else {
                ESP_LOGE(TAG,
                         "SD WATCHDOG: ERROR (%s) - KORVO continues running",
                         esp_err_to_name(err));
            }
            last_ok = ok;
            first_sample = false;
        }

        /*
         * SD failure must never create a reboot loop. The watchdog keeps
         * checking and the HMI remains operational so the fault is visible.
         */
        vTaskDelay(pdMS_TO_TICKS(STORAGE_WATCHDOG_POLL_MS));
    }
}


void app_main(void)
{
    esp_err_t ret = ESP_OK;

    /* Diagnostic boot reason. No automatic cold-boot restart. */
    esp_reset_reason_t boot_reason = esp_reset_reason();
    ESP_LOGI(TAG, "BOOT reset_reason=%d automatic_restart=DISABLED",
             (int)boot_reason);

    bsp_display_start();

    /*
     * ESP32-S31-Korvo-1 cold power-on stabilization.
     * Delay OV3660/DVP initialization until board rails/clocks are stable.
     */
    ESP_LOGI(TAG, "Cold boot camera stabilization (1000 ms)...");
    vTaskDelay(pdMS_TO_TICKS(1000));

    /* Initialize Camera - robust cold boot startup */
    ESP_LOGI(TAG, "Starting camera...");

    esp_err_t camera_ret = ESP_FAIL;
    for (int attempt = 1; attempt <= CAMERA_START_RETRIES; attempt++) {
        camera_ret = bsp_camera_start(NULL);
        if (camera_ret == ESP_OK) {
            ESP_LOGI(TAG, "Camera initialized on attempt %d", attempt);
            break;
        }

        ESP_LOGW(TAG, "Camera init attempt %d failed: %s",
                 attempt, esp_err_to_name(camera_ret));
        vTaskDelay(pdMS_TO_TICKS(300));
    }

    if (camera_ret != ESP_OK) {
        ESP_LOGE(TAG, "Camera initialization failed after %d attempts - restarting",
                 CAMERA_START_RETRIES);
        vTaskDelay(pdMS_TO_TICKS(1000));
        esp_restart();
    }

    /* Mount microSD and create/verify the standard KORVO directory tree. */
    ESP_LOGI(TAG, "Initializing KORVO storage...");
    esp_err_t storage_ret = korvo_storage_init();
    if (storage_ret != ESP_OK) {
        ESP_LOGW(TAG, "KORVO storage unavailable: %s - continuing without SD",
                 esp_err_to_name(storage_ret));
    } else {
        ESP_LOGI(TAG, "KORVO storage ready at %s (layout v%s)",
                 korvo_storage_root(), korvo_storage_layout_version());

        /*
         * SD UPDATE MANAGER runs before camera/HMI/network. A firmware uploaded
         * from the web and marked pending is validated again and installed into
         * the inactive OTA partition. On success this function reboots.
         */
        esp_err_t update_ret = korvo_update_boot_check();
        if (update_ret != ESP_OK && update_ret != ESP_ERR_NOT_FOUND) {
            ESP_LOGE(TAG, "Pending firmware update was NOT installed: %s",
                     esp_err_to_name(update_ret));
        }
    }

#if SOC_PPA_SUPPORTED
    /* Initialize PPA for scaling */
    app_ppa_init();
#endif

    /* Get cache alignment */
    ret = esp_cache_get_alignment(MALLOC_CAP_SPIRAM, &data_cache_line_size);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Get cache alignment failed: 0x%x", ret);
        return;
    }

    /* Allocate canvas buffers */
    cam_buff_size = ALIGN_UP(BSP_LCD_H_RES * BSP_LCD_V_RES * 2, data_cache_line_size);
    for (int i = 0; i < NUM_BUFS; i++) {
        cam_buff[i] = heap_caps_aligned_calloc(data_cache_line_size, 1, cam_buff_size, MALLOC_CAP_SPIRAM);
        if (cam_buff[i] == NULL) {
            ESP_LOGE(TAG, "Failed to allocate camera buffer %d", i);
            return;
        }
    }

    /* Dedicated full VGA RGB565 buffer for ESP-DL */
    face_ai_buffer_size = 640U * 480U * 2U;
    face_ai_buffer = heap_caps_malloc(face_ai_buffer_size, MALLOC_CAP_SPIRAM);
    if (face_ai_buffer == NULL) {
        ESP_LOGE(TAG, "Failed to allocate face AI buffer (%u bytes)",
                 (unsigned)face_ai_buffer_size);
        return;
    }

    face_ai_mutex = xSemaphoreCreateMutex();
    if (face_ai_mutex == NULL) {
        ESP_LOGE(TAG, "Failed to create face AI mutex");
        return;
    }

    /* Open video first: pixel format comes from menuconfig / driver (VIDIOC_G_FMT). */
    int fd = -1;
    for (int attempt = 1; attempt <= VIDEO_OPEN_RETRIES; attempt++) {
        fd = app_video_open(BSP_CAMERA_DEVICE, APP_VIDEO_FMT_DRIVER_DEFAULT);
        if (fd >= 0) {
            ESP_LOGI(TAG, "Video device opened on attempt %d", attempt);
            break;
        }

        ESP_LOGW(TAG, "Video device not ready, attempt %d/%d",
                 attempt, VIDEO_OPEN_RETRIES);
        vTaskDelay(pdMS_TO_TICKS(200));
    }

    if (fd < 0) {
        ESP_LOGE(TAG, "Failed to open video device after %d attempts - restarting",
                 VIDEO_OPEN_RETRIES);
        vTaskDelay(pdMS_TO_TICKS(1000));
        esp_restart();
    }
    lvgl_cam_rgb565_fmt = lvgl_rgb565_fmt_from_v4l2(app_video_get_pixelformat());

    /* Create LVGL canvas for camera image */
    bsp_display_lock(0);
    camera_canvas = lv_canvas_create(lv_scr_act());
    lv_canvas_set_buffer(camera_canvas, cam_buff[0], BSP_LCD_H_RES, BSP_LCD_V_RES, lvgl_cam_rgb565_fmt);
    assert(camera_canvas);
    lv_obj_center(camera_canvas);
/* ===== KORVO ACCESS HMI ===== */
    korvo_hmi_init();

    bsp_display_unlock();

    /*
     * SD runtime watchdog starts after HMI creation so its first sample can
     * immediately populate the upper-right SD card.
     */
    BaseType_t storage_wd_ret = xTaskCreate(
        storage_watchdog_task,
        "sd_watchdog",
        4096,
        NULL,
        3,
        NULL
    );
    if (storage_wd_ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create SD watchdog task");
        korvo_hmi_update_storage(false, false, false, 0, 0, 0);
    }

    /* Initialize video capture device */
    ret = app_video_set_bufs(fd, NUM_BUFS, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to set video buffers: 0x%x", ret);
        return;
    }

    /* Register frame process callback */
    ret = app_video_register_frame_operation_cb(camera_video_frame_operation);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to register frame operation callback: 0x%x", ret);
        return;
    }

    /* Start video stream task */
    ret = app_video_stream_task_start(fd, 0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Failed to start video stream task: 0x%x - restarting", ret);
        vTaskDelay(pdMS_TO_TICKS(1000));
        esp_restart();
    }

    /*
     * CAMERA HEALTH WATCHDOG:
     * FPS alone is not accepted. Require real RGB565 motion percentages.
     * 0.0% is valid. Timeout means restart and another autonomous boot attempt.
     */
    camera_health_valid_samples = 0;
    motion_frame_counter = 0;
    free(motion_reference);
    motion_reference = NULL;
    motion_reference_count = 0;

    ESP_LOGI(TAG, "CAMERA HEALTH CHECK - waiting for %d valid motion samples (%d ms timeout)",
             CAMERA_HEALTH_VALID_SAMPLES, CAMERA_HEALTH_TIMEOUT_MS);

    TickType_t camera_health_start = xTaskGetTickCount();
    while (camera_health_valid_samples < CAMERA_HEALTH_VALID_SAMPLES) {
        if ((xTaskGetTickCount() - camera_health_start) >=
            pdMS_TO_TICKS(CAMERA_HEALTH_TIMEOUT_MS)) {
            ESP_LOGE(TAG,
                     "CAMERA HEALTH FAILED - motion %% invalid (%lu/%d) - restarting",
                     (unsigned long)camera_health_valid_samples,
                     CAMERA_HEALTH_VALID_SAMPLES);
            vTaskDelay(pdMS_TO_TICKS(500));
            esp_restart();
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }

    ESP_LOGI(TAG, "CAMERA HEALTH OK - motion %% valid (%lu/%d)",
             (unsigned long)camera_health_valid_samples,
             CAMERA_HEALTH_VALID_SAMPLES);

    /* KORVO network/web starts only after validated camera health. */
    esp_err_t network_ret = korvo_network_init();
    if (network_ret != ESP_OK) {
        ESP_LOGE(TAG, "KORVO network unavailable: %s", esp_err_to_name(network_ret));
    } else {
        esp_err_t web_ret = korvo_web_start();
        if (web_ret != ESP_OK) {
            ESP_LOGE(TAG, "KORVO web server unavailable: %s", esp_err_to_name(web_ret));
        }
    }

    /*
     * Permanent runtime camera watchdog. The RGB565 motion processor owns
     * the heartbeat; if it stops for 10 seconds KORVO restarts autonomously.
     */
    camera_last_valid_frame_tick = xTaskGetTickCount();
    camera_runtime_watchdog_enabled = true;

    BaseType_t camera_wd_ret = xTaskCreate(
        camera_runtime_watchdog_task,
        "camera_watchdog",
        4096,
        NULL,
        4,
        NULL
    );
    if (camera_wd_ret != pdPASS) {
        camera_runtime_watchdog_enabled = false;
        ESP_LOGE(TAG, "Failed to create camera runtime watchdog task");
    }


    /*
     * CAMERA-FIRST BOOT:
     * At this point display + camera + video stream are already running.
     * Keep the camera visible and do not start motion/screensaver or ESP-DL
     * until 10 full seconds after KORVO READY.
     */
    korvo_awake = true;
    korvo_hmi_wake();
    ESP_LOGI(TAG, "KORVO READY - camera visualization only for %d ms",
             KORVO_SERVICES_START_DELAY_MS);

    vTaskDelay(pdMS_TO_TICKS(KORVO_SERVICES_START_DELAY_MS));

    /*
     * Start the inactivity clock NOW, not during boot. This guarantees a
     * fresh 10-second inactivity window after auxiliary services start.
     */
    TickType_t services_start_tick = xTaskGetTickCount();
    last_motion_tick = services_start_tick;
    last_face_tick = services_start_tick;
    motion_confirm_count = 0;
    motion_clear_count = 0;
    motion_active = false;
    korvo_services_enabled = true;

    ESP_LOGI(TAG, "KORVO auxiliary services ENABLED: motion/screensaver + ESP-DL");

    BaseType_t ai_task_ret = xTaskCreate(
        face_detection_task,
        "face_ai",
        8192,
        NULL,
        5,
        NULL
    );

    if (ai_task_ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create face detection task");
    } else {
        ESP_LOGI(TAG, "ESP-DL face detection task started");
    }

    /*
     * Do NOT force the screensaver here. Motion owns standby from now on
     * and may activate it only after a complete inactivity interval.
     */
}
