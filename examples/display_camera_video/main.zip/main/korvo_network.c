#include "korvo_network.h"

#include <string.h>

#include "esp_event.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "nvs.h"
#include "nvs_flash.h"

static const char *TAG = "korvo_network";
static const char *NVS_NS = "korvo_net";

static bool s_started;
static bool s_connected;
static esp_netif_t *s_sta_netif;
static korvo_network_config_t s_cfg;

static void defaults(korvo_network_config_t *c)
{
    memset(c, 0, sizeof(*c));

    strlcpy(
        c->ssid,
        KORVO_WIFI_DEFAULT_SSID,
        sizeof(c->ssid));

    strlcpy(
        c->password,
        KORVO_WIFI_DEFAULT_PASSWORD,
        sizeof(c->password));

    strlcpy(
        c->ip,
        KORVO_WIFI_DEFAULT_IP,
        sizeof(c->ip));

    strlcpy(
        c->netmask,
        KORVO_WIFI_DEFAULT_NETMASK,
        sizeof(c->netmask));

    strlcpy(
        c->network_gateway,
        KORVO_WIFI_DEFAULT_GATEWAY,
        sizeof(c->network_gateway));

    strlcpy(
        c->dns,
        KORVO_WIFI_DEFAULT_DNS,
        sizeof(c->dns));

    strlcpy(
        c->gateway_node_ip,
        KORVO_GATEWAY_DEFAULT_IP,
        sizeof(c->gateway_node_ip));

    c->ssid_visible = true;
}

static bool valid_ip(const char *s)
{
    esp_ip4_addr_t a;

    return
        s &&
        esp_netif_str_to_ip4(
            s,
            &a) == ESP_OK;
}

static bool valid_cfg(const korvo_network_config_t *c)
{
    size_t n =
        c
            ? strlen(c->password)
            : 0;

    return
        c &&
        c->ssid[0] &&
        (n == 0 || (n >= 8 && n <= 63)) &&
        valid_ip(c->ip) &&
        valid_ip(c->netmask) &&
        valid_ip(c->network_gateway) &&
        (!c->dns[0] || valid_ip(c->dns)) &&
        valid_ip(c->gateway_node_ip);
}

static esp_err_t load_cfg(korvo_network_config_t *c)
{
    defaults(c);

    nvs_handle_t h;

    esp_err_t e =
        nvs_open(
            NVS_NS,
            NVS_READONLY,
            &h);

    if (e == ESP_ERR_NVS_NOT_FOUND) {
        return ESP_OK;
    }

    if (e != ESP_OK) {
        return e;
    }

    size_t n;

    n = sizeof(c->ssid);
    (void)nvs_get_str(
        h,
        "ssid",
        c->ssid,
        &n);

    n = sizeof(c->password);
    (void)nvs_get_str(
        h,
        "pass",
        c->password,
        &n);

    n = sizeof(c->ip);
    (void)nvs_get_str(
        h,
        "ip",
        c->ip,
        &n);

    n = sizeof(c->netmask);
    (void)nvs_get_str(
        h,
        "mask",
        c->netmask,
        &n);

    /*
     * Nuevas claves:
     * netgw = gateway IP real de la LAN
     * dns   = DNS
     * node  = Gateway/controlador KORVO
     *
     * La clave antigua "gw" no se reutiliza para evitar confundir
     * el antiguo gateway-node 192.168.5.51 con el gateway IP.
     */
    n = sizeof(c->network_gateway);
    (void)nvs_get_str(
        h,
        "netgw",
        c->network_gateway,
        &n);

    n = sizeof(c->dns);
    (void)nvs_get_str(
        h,
        "dns",
        c->dns,
        &n);

    n = sizeof(c->gateway_node_ip);
    esp_err_t node_e =
        nvs_get_str(
            h,
            "node",
            c->gateway_node_ip,
            &n);

    /*
     * Migración suave:
     * si todavía no existe "node", no tomamos la antigua "gw"
     * porque pertenece a la arquitectura 192.168.5.x.
     * Se mantiene el nuevo valor por defecto 192.168.10.51.
     */
    (void)node_e;

    nvs_close(h);

    if (!valid_cfg(c)) {
        defaults(c);
    }

    return ESP_OK;
}

static void wifi_event(
    void *arg,
    esp_event_base_t base,
    int32_t id,
    void *data)
{
    (void)arg;
    (void)data;

    if (base != WIFI_EVENT) {
        return;
    }

    if (id == WIFI_EVENT_STA_START) {

        ESP_LOGI(
            TAG,
            "Wi-Fi STA iniciado; conectando a SSID=%s",
            s_cfg.ssid);

        esp_err_t e =
            esp_wifi_connect();

        if (e != ESP_OK) {
            ESP_LOGE(
                TAG,
                "esp_wifi_connect fallo: %s",
                esp_err_to_name(e));
        }

    } else if (id == WIFI_EVENT_STA_CONNECTED) {

        s_connected = true;

        ESP_LOGI(
            TAG,
            "Wi-Fi asociado a SSID=%s",
            s_cfg.ssid);

    } else if (id == WIFI_EVENT_STA_DISCONNECTED) {

        s_connected = false;

        ESP_LOGW(
            TAG,
            "Wi-Fi desconectado; reintentando SSID=%s",
            s_cfg.ssid);

        esp_err_t e =
            esp_wifi_connect();

        if (e != ESP_OK) {
            ESP_LOGE(
                TAG,
                "Reconexion Wi-Fi fallo: %s",
                esp_err_to_name(e));
        }
    }
}

static esp_err_t configure_static_ip(void)
{
    if (!s_sta_netif) {
        return ESP_ERR_INVALID_STATE;
    }

    esp_netif_ip_info_t ip = {0};

    if (esp_netif_str_to_ip4(
            s_cfg.ip,
            &ip.ip) != ESP_OK ||
        esp_netif_str_to_ip4(
            s_cfg.netmask,
            &ip.netmask) != ESP_OK ||
        esp_netif_str_to_ip4(
            s_cfg.network_gateway,
            &ip.gw) != ESP_OK) {

        return ESP_ERR_INVALID_ARG;
    }

    esp_err_t e =
        esp_netif_dhcpc_stop(
            s_sta_netif);

    if (e != ESP_OK &&
        e != ESP_ERR_ESP_NETIF_DHCP_ALREADY_STOPPED) {

        return e;
    }

    e =
        esp_netif_set_ip_info(
            s_sta_netif,
            &ip);

    if (e != ESP_OK) {
        return e;
    }

    if (s_cfg.dns[0]) {
        esp_netif_dns_info_t dns = {0};
        dns.ip.type = ESP_IPADDR_TYPE_V4;
        if (esp_netif_str_to_ip4(s_cfg.dns, &dns.ip.u_addr.ip4) != ESP_OK) return ESP_ERR_INVALID_ARG;
        e = esp_netif_set_dns_info(s_sta_netif, ESP_NETIF_DNS_MAIN, &dns);
        if (e != ESP_OK) return e;
    }

    ESP_LOGI(
        TAG,
        "IP fija KORVO: %s/%s gateway-lan=%s dns=%s",
        s_cfg.ip,
        s_cfg.netmask,
        s_cfg.network_gateway,
        s_cfg.dns[0] ? s_cfg.dns : "DISABLED");

    return ESP_OK;
}

esp_err_t korvo_network_init(void)
{
    if (s_started) {
        return ESP_OK;
    }

    esp_err_t e =
        nvs_flash_init();

    if (e == ESP_ERR_NVS_NO_FREE_PAGES ||
        e == ESP_ERR_NVS_NEW_VERSION_FOUND) {

        ESP_ERROR_CHECK(
            nvs_flash_erase());

        e =
            nvs_flash_init();
    }

    if (e != ESP_OK) {
        return e;
    }

    if (load_cfg(&s_cfg) != ESP_OK) {
        defaults(&s_cfg);
    }

    e =
        esp_netif_init();

    if (e != ESP_OK &&
        e != ESP_ERR_INVALID_STATE) {

        return e;
    }

    e =
        esp_event_loop_create_default();

    if (e != ESP_OK &&
        e != ESP_ERR_INVALID_STATE) {

        return e;
    }

    s_sta_netif =
        esp_netif_create_default_wifi_sta();

    if (!s_sta_netif) {
        return ESP_FAIL;
    }

    e =
        configure_static_ip();

    if (e != ESP_OK) {
        return e;
    }

    wifi_init_config_t wi =
        WIFI_INIT_CONFIG_DEFAULT();

    e =
        esp_wifi_init(
            &wi);

    if (e != ESP_OK) {
        return e;
    }

    e =
        esp_event_handler_register(
            WIFI_EVENT,
            ESP_EVENT_ANY_ID,
            wifi_event,
            NULL);

    if (e != ESP_OK) {
        return e;
    }

    wifi_config_t sta = {0};

    strlcpy(
        (char *)sta.sta.ssid,
        s_cfg.ssid,
        sizeof(sta.sta.ssid));

    strlcpy(
        (char *)sta.sta.password,
        s_cfg.password,
        sizeof(sta.sta.password));

    sta.sta.scan_method =
        WIFI_ALL_CHANNEL_SCAN;

    sta.sta.sort_method =
        WIFI_CONNECT_AP_BY_SIGNAL;

    sta.sta.threshold.authmode =
        strlen(s_cfg.password)
            ? WIFI_AUTH_WPA2_PSK
            : WIFI_AUTH_OPEN;

    e =
        esp_wifi_set_mode(
            WIFI_MODE_STA);

    if (e != ESP_OK) {
        return e;
    }

    e =
        esp_wifi_set_config(
            WIFI_IF_STA,
            &sta);

    if (e != ESP_OK) {
        return e;
    }

    e =
        esp_wifi_start();

    if (e != ESP_OK) {
        return e;
    }

    s_started = true;

    ESP_LOGI(
        TAG,
        "STA READY ssid=%s ip=%s gateway-lan=%s gateway-io=%s",
        s_cfg.ssid,
        s_cfg.ip,
        s_cfg.network_gateway,
        s_cfg.gateway_node_ip);

    return ESP_OK;
}

esp_err_t korvo_network_get_status(
    korvo_network_status_t *s)
{
    if (!s) {
        return ESP_ERR_INVALID_ARG;
    }

    memset(
        s,
        0,
        sizeof(*s));

    s->started =
        s_started;

    s->connected =
        s_connected;

    /*
     * Se conserva el campo por compatibilidad de API.
     * KORVO ahora es STA, por lo que no aloja clientes Wi-Fi.
     */
    s->connected_clients =
        0;

    s->config =
        s_cfg;

    if (s_started) {
        (void)esp_wifi_get_mac(
            WIFI_IF_STA,
            s->mac);
    }

    return ESP_OK;
}

esp_err_t korvo_network_get_config(
    korvo_network_config_t *c)
{
    if (!c) {
        return ESP_ERR_INVALID_ARG;
    }

    *c =
        s_cfg;

    return ESP_OK;
}

esp_err_t korvo_network_save_config(
    const korvo_network_config_t *c)
{
    if (!valid_cfg(c)) {
        return ESP_ERR_INVALID_ARG;
    }

    nvs_handle_t h;

    esp_err_t e =
        nvs_open(
            NVS_NS,
            NVS_READWRITE,
            &h);

    if (e != ESP_OK) {
        return e;
    }

    if ((e = nvs_set_str(
            h,
            "ssid",
            c->ssid)) == ESP_OK &&
        (e = nvs_set_str(
            h,
            "pass",
            c->password)) == ESP_OK &&
        (e = nvs_set_str(
            h,
            "ip",
            c->ip)) == ESP_OK &&
        (e = nvs_set_str(
            h,
            "mask",
            c->netmask)) == ESP_OK &&
        (e = nvs_set_str(
            h,
            "netgw",
            c->network_gateway)) == ESP_OK &&
        (e = nvs_set_str(
            h,
            "dns",
            c->dns)) == ESP_OK &&
        (e = nvs_set_str(
            h,
            "node",
            c->gateway_node_ip)) == ESP_OK) {

        e =
            nvs_commit(
                h);
    }

    nvs_close(h);

    if (e == ESP_OK) {
        s_cfg =
            *c;
    }

    return e;
}

esp_err_t korvo_network_factory_defaults(void)
{
    korvo_network_config_t c;

    defaults(
        &c);

    return korvo_network_save_config(
        &c);
}
