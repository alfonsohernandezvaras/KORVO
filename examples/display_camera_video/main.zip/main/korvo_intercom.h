#pragma once
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

esp_err_t korvo_intercom_init(void);

#ifdef __cplusplus
}
#endif
