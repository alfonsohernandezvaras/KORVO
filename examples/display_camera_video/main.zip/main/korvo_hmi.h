#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "face_detect.h"
#include "korvo_bluetooth.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    KORVO_HMI_FACE_NONE = 0,
    KORVO_HMI_FACE_POSITION,
    KORVO_HMI_FACE_HOLD_STILL,
    KORVO_HMI_FACE_READY
} korvo_hmi_face_state_t;

void korvo_hmi_init(void);
void korvo_hmi_sleep(void);
void korvo_hmi_wake(void);

/* Clear temporal face stability immediately when ESP-DL loses the face. */
void korvo_hmi_no_face(void);

/*
 * Feed one ESP-DL face sample into the geometric + temporal validation
 * matrix. READY is reached only after several stable consecutive samples.
 */
void korvo_hmi_update_face(const face_detection_t *face,
                           uint16_t camera_width,
                           uint16_t camera_height);

/* Dynamic ESP-DL overlay: bounding box + center marker. */
void korvo_hmi_track_face(const face_detection_t *face,
                          uint16_t camera_width,
                          uint16_t camera_height);
void korvo_hmi_hide_face_track(void);

/* Temporary motion/standby engineering diagnostic. */
void korvo_hmi_update_motion(uint32_t motion_percent_x10,
                             bool moving,
                             uint32_t idle_ms,
                             uint32_t sleep_ms);

/* Compact SD status card shown at the upper-right corner. */
void korvo_hmi_update_storage(bool sd_ok,
                              bool fs_ok,
                              bool structure_ok,
                              int storage_state,
                              uint64_t used_bytes,
                              uint64_t free_bytes);


/* Permanent bottom status strip. Central camera/face ROI stays free of status text. */
/* Dedicated local Bluetooth screen. Same backend as the remote web UI. */
void korvo_hmi_update_bluetooth(const korvo_bluetooth_status_t *bt);

void korvo_hmi_update_gateway_status(const char *room,
                                     const char *gateway_name,
                                     bool gateway_ok,
                                     bool control_ok,
                                     bool sip_registered,
                                     const char *sip_state,
                                     bool bt_enabled,
                                     bool bt_paired,
                                     bool bt_connected,
                                     const char *bt_peer);

korvo_hmi_face_state_t korvo_hmi_face_state(void);

#ifdef __cplusplus
}
#endif
