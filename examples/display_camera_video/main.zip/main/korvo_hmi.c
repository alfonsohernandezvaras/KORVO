#include "korvo_hmi.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "bsp/esp-bsp.h"
#include "esp_log.h"
#include "korvo_bluetooth.h"

static const char *TAG = "korvo_hmi";

static lv_obj_t *s_guide = NULL;
static lv_obj_t *s_message = NULL;
static lv_obj_t *s_face_box = NULL;
static lv_obj_t *s_face_center = NULL;
static lv_obj_t *s_motion_diag = NULL;
static lv_obj_t *s_storage_diag = NULL;
static lv_obj_t *s_gateway_footer = NULL;
static lv_obj_t *s_volume_slider = NULL;
static lv_obj_t *s_volume_label = NULL;
static lv_obj_t *s_mic_slider = NULL;
static lv_obj_t *s_mic_label = NULL;

/* Dedicated local Bluetooth UI. It is a full-screen mode, hidden when not in use,
 * so the camera view is restored cleanly with no persistent overlay. */
static lv_obj_t *s_bt_panel = NULL;
static lv_obj_t *s_bt_status_label = NULL;
static lv_obj_t *s_bt_error_label = NULL;
static lv_obj_t *s_bt_power_btn = NULL;
static lv_obj_t *s_bt_power_btn_label = NULL;
static lv_obj_t *s_bt_scan_btn = NULL;
static lv_obj_t *s_bt_scan_btn_label = NULL;
static lv_obj_t *s_bt_link_btn = NULL;
static lv_obj_t *s_bt_link_btn_label = NULL;
static lv_obj_t *s_bt_list = NULL;
static lv_obj_t *s_bt_list_hint = NULL;
static lv_obj_t *s_bt_device_row[KORVO_BT_SCAN_MAX] = {0};
static lv_obj_t *s_bt_device_label[KORVO_BT_SCAN_MAX] = {0};
static lv_obj_t *s_bt_device_btn[KORVO_BT_SCAN_MAX] = {0};
static lv_obj_t *s_bt_device_btn_label[KORVO_BT_SCAN_MAX] = {0};
static char s_bt_device_mac[KORVO_BT_SCAN_MAX][KORVO_BT_MAC_MAX] = {{0}};
static volatile bool s_bt_panel_visible = false;

static bool s_awake = false;
static korvo_hmi_face_state_t s_face_state = KORVO_HMI_FACE_NONE;

/* Tall portrait guide agreed for the KORVO access terminal. */
#define GUIDE_W_PERCENT  46
#define GUIDE_H_PERCENT  78

/*
 * Face quality matrix.
 *
 * A single ESP-DL detection is NEVER enough for READY.
 * We validate geometry, size, aspect and temporal stability.
 */
#define FACE_MIN_W_PERCENT          28
#define FACE_MIN_H_PERCENT          34
#define FACE_CENTER_X_MIN_PERCENT   27
#define FACE_CENTER_X_MAX_PERCENT   73
#define FACE_CENTER_Y_MIN_PERCENT   18
#define FACE_CENTER_Y_MAX_PERCENT   82

/* Reject extremely thin/wide detector boxes as unusable face candidates. */
#define FACE_ASPECT_MIN_PERCENT     55
#define FACE_ASPECT_MAX_PERCENT     125

/*
 * Temporal stability thresholds between consecutive detector samples.
 * Percentages are relative to camera dimensions / previous face size.
 */
#define STABLE_CENTER_DELTA_X_PERCENT   4
#define STABLE_CENTER_DELTA_Y_PERCENT   4
#define STABLE_SIZE_DELTA_PERCENT       10

/* Require this many consecutive good/stable samples before READY. */
#define READY_STABLE_SAMPLES            5

typedef struct {
    bool valid;
    int cx;
    int cy;
    int w;
    int h;
    uint32_t stable_samples;
} face_track_t;

static face_track_t s_track = {0};

static lv_obj_t *make_touch_button(lv_obj_t *parent, const char *text,
                                   int width, int height, lv_obj_t **label_out)
{
    lv_obj_t *btn = lv_obj_create(parent);
    lv_obj_remove_style_all(btn);
    lv_obj_set_size(btn, width, height);
    lv_obj_set_style_bg_color(btn, lv_palette_darken(LV_PALETTE_BLUE, 2), 0);
    lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(btn, 1, 0);
    lv_obj_set_style_border_color(btn, lv_palette_lighten(LV_PALETTE_BLUE, 2), 0);
    lv_obj_set_style_radius(btn, 8, 0);
    lv_obj_clear_flag(btn, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(btn, LV_OBJ_FLAG_CLICKABLE);

    lv_obj_t *label = lv_label_create(btn);
    lv_label_set_text(label, text ? text : "");
    lv_obj_set_style_text_color(label, lv_color_white(), 0);
    lv_obj_center(label);
    if (label_out) *label_out = label;
    return btn;
}

static void bt_local_set_error(const char *text)
{
    if (!s_bt_error_label) return;
    lv_label_set_text(s_bt_error_label, (text && text[0]) ? text : "--");
}

static void volume_label_update(uint8_t value)
{
    if (!s_volume_label) return;
    char text[24];
    snprintf(text, sizeof(text), "VOL\n%u%%", (unsigned)value);
    lv_label_set_text(s_volume_label, text);
}

static void volume_slider_cb(lv_event_t *e)
{
    if (!s_volume_slider) return;
    int value = lv_slider_get_value(s_volume_slider);
    if (value < 0) value = 0;
    if (value > 100) value = 100;

    bool persist = lv_event_get_code(e) == LV_EVENT_RELEASED;
    esp_err_t err = korvo_bluetooth_set_output_volume((uint8_t)value, persist);
    if (err == ESP_OK) {
        volume_label_update((uint8_t)value);
    } else {
        ESP_LOGW(TAG, "Volume update failed: %s", esp_err_to_name(err));
    }
}

static void mic_label_update(uint8_t value)
{
    if (!s_mic_label) return;
    char text[24];
    snprintf(text, sizeof(text), "MIC\n%u%%", (unsigned)value);
    lv_label_set_text(s_mic_label, text);
}

static void mic_slider_cb(lv_event_t *e)
{
    if (!s_mic_slider) return;
    int value = lv_slider_get_value(s_mic_slider);
    if (value < 0) value = 0;
    if (value > 100) value = 100;
    bool persist = lv_event_get_code(e) == LV_EVENT_RELEASED;
    esp_err_t err = korvo_bluetooth_set_mic_gain((uint8_t)value, persist);
    if (err == ESP_OK) mic_label_update((uint8_t)value);
    else ESP_LOGW(TAG, "Mic gain update failed: %s", esp_err_to_name(err));
}

static void bt_open_cb(lv_event_t *e)
{
    (void)e;
    if (!s_bt_panel) return;
    s_bt_panel_visible = true;
    lv_obj_clear_flag(s_bt_panel, LV_OBJ_FLAG_HIDDEN);
    lv_obj_move_foreground(s_bt_panel);
}

static void bt_back_cb(lv_event_t *e)
{
    (void)e;
    if (!s_bt_panel) return;
    s_bt_panel_visible = false;
    lv_obj_add_flag(s_bt_panel, LV_OBJ_FLAG_HIDDEN);
}

static void bt_power_cb(lv_event_t *e)
{
    (void)e;
    korvo_bluetooth_config_t cfg = {0};
    esp_err_t err = korvo_bluetooth_get_config(&cfg);
    if (err == ESP_OK) {
        cfg.enabled = !cfg.enabled;
        err = korvo_bluetooth_save_config(&cfg);
    }
    bt_local_set_error(err == ESP_OK ? "--" : esp_err_to_name(err));
}

static void bt_scan_cb(lv_event_t *e)
{
    (void)e;
    esp_err_t err = korvo_bluetooth_scan();
    bt_local_set_error(err == ESP_OK ? "Escaneando dispositivos..." : esp_err_to_name(err));
}

static void bt_link_cb(lv_event_t *e)
{
    (void)e;
    korvo_bluetooth_status_t st = {0};
    korvo_bluetooth_get_status(&st);
    esp_err_t err = ESP_ERR_INVALID_STATE;

    if (st.slc_connected || st.connecting) {
        err = korvo_bluetooth_disconnect();
        bt_local_set_error(err == ESP_OK ? "Desconectando HFP..." : esp_err_to_name(err));
        return;
    }

    korvo_bluetooth_config_t cfg = {0};
    if (korvo_bluetooth_get_config(&cfg) == ESP_OK && cfg.peer_mac[0]) {
        err = korvo_bluetooth_connect(cfg.peer_mac);
    }
    bt_local_set_error(err == ESP_OK ? "Conectando HFP..." : esp_err_to_name(err));
}

static void bt_forget_cb(lv_event_t *e)
{
    (void)e;
    esp_err_t err = korvo_bluetooth_forget();
    bt_local_set_error(err == ESP_OK ? "Dispositivo olvidado" : esp_err_to_name(err));
}

static void bt_device_cb(lv_event_t *e)
{
    lv_obj_t *target = lv_event_get_current_target_obj(e);
    for (size_t i = 0; i < KORVO_BT_SCAN_MAX; ++i) {
        /* The whole device row is touchable, not only the small action button.
         * This makes local pairing behave like the web UI and is much easier
         * to use on the 800x480 touch panel. */
        if (target == s_bt_device_btn[i] || target == s_bt_device_row[i]) {
            if (!s_bt_device_mac[i][0]) return;
            esp_err_t err = korvo_bluetooth_connect(s_bt_device_mac[i]);
            bt_local_set_error(err == ESP_OK ? "PAIR / conexion iniciada..." : esp_err_to_name(err));
            return;
        }
    }
}

static void build_bluetooth_panel(lv_obj_t *screen)
{
    s_bt_panel = lv_obj_create(screen);
    lv_obj_remove_style_all(s_bt_panel);
    lv_obj_set_pos(s_bt_panel, 0, 0);
    lv_obj_set_size(s_bt_panel, BSP_LCD_H_RES, BSP_LCD_V_RES);
    lv_obj_set_style_bg_color(s_bt_panel, lv_color_hex(0x101820), 0);
    lv_obj_set_style_bg_opa(s_bt_panel, LV_OPA_COVER, 0);
    lv_obj_clear_flag(s_bt_panel, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *back = make_touch_button(s_bt_panel, "< CAMARA", 110, 40, NULL);
    lv_obj_align(back, LV_ALIGN_TOP_LEFT, 8, 8);
    lv_obj_add_event_cb(back, bt_back_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *title = lv_label_create(s_bt_panel);
    lv_label_set_text(title, "BLUETOOTH");
    lv_obj_set_style_text_color(title, lv_color_white(), 0);
    lv_obj_align(title, LV_ALIGN_TOP_MID, 0, 16);

    s_bt_power_btn = make_touch_button(s_bt_panel, "ENCENDER", 150, 40, &s_bt_power_btn_label);
    lv_obj_align(s_bt_power_btn, LV_ALIGN_TOP_RIGHT, -8, 8);
    lv_obj_add_event_cb(s_bt_power_btn, bt_power_cb, LV_EVENT_CLICKED, NULL);

    s_bt_status_label = lv_label_create(s_bt_panel);
    lv_label_set_text(s_bt_status_label, "BLUETOOTH: --\nPAIR: --\nHFP: --   AUDIO: --");
    lv_obj_set_width(s_bt_status_label, BSP_LCD_H_RES - 24);
    lv_obj_set_style_text_color(s_bt_status_label, lv_color_white(), 0);
    lv_obj_set_style_bg_color(s_bt_status_label, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s_bt_status_label, LV_OPA_40, 0);
    lv_obj_set_style_pad_all(s_bt_status_label, 6, 0);
    lv_obj_align(s_bt_status_label, LV_ALIGN_TOP_MID, 0, 56);

    s_bt_scan_btn = make_touch_button(s_bt_panel, "SCAN", 110, 38, &s_bt_scan_btn_label);
    lv_obj_align(s_bt_scan_btn, LV_ALIGN_TOP_LEFT, 8, 112);
    lv_obj_add_event_cb(s_bt_scan_btn, bt_scan_cb, LV_EVENT_CLICKED, NULL);

    s_bt_link_btn = make_touch_button(s_bt_panel, "CONECTAR", 135, 38, &s_bt_link_btn_label);
    lv_obj_align(s_bt_link_btn, LV_ALIGN_TOP_LEFT, 126, 112);
    lv_obj_add_event_cb(s_bt_link_btn, bt_link_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *forget = make_touch_button(s_bt_panel, "OLVIDAR", 100, 38, NULL);
    lv_obj_align(forget, LV_ALIGN_TOP_LEFT, 269, 112);
    lv_obj_add_event_cb(forget, bt_forget_cb, LV_EVENT_CLICKED, NULL);

    s_bt_error_label = lv_label_create(s_bt_panel);
    lv_label_set_text(s_bt_error_label, "--");
    lv_obj_set_width(s_bt_error_label, BSP_LCD_H_RES - 390);
    lv_obj_set_style_text_color(s_bt_error_label, lv_palette_main(LV_PALETTE_ORANGE), 0);
    lv_obj_align(s_bt_error_label, LV_ALIGN_TOP_RIGHT, -8, 122);

    s_bt_list = lv_obj_create(s_bt_panel);
    lv_obj_set_pos(s_bt_list, 8, 158);
    lv_obj_set_size(s_bt_list, BSP_LCD_H_RES - 16, BSP_LCD_V_RES - 166);
    lv_obj_set_style_bg_color(s_bt_list, lv_color_hex(0x18232e), 0);
    lv_obj_set_style_bg_opa(s_bt_list, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(s_bt_list, 1, 0);
    lv_obj_set_style_border_color(s_bt_list, lv_color_hex(0x405466), 0);
    lv_obj_set_style_pad_all(s_bt_list, 4, 0);
    lv_obj_add_flag(s_bt_list, LV_OBJ_FLAG_SCROLLABLE);

    s_bt_list_hint = lv_label_create(s_bt_list);
    lv_label_set_text(s_bt_list_hint, "Pulse SCAN y ponga el dispositivo en modo pairing.");
    lv_obj_set_width(s_bt_list_hint, BSP_LCD_H_RES - 70);
    lv_obj_set_style_text_color(s_bt_list_hint, lv_palette_lighten(LV_PALETTE_GREY, 2), 0);
    lv_obj_set_style_text_align(s_bt_list_hint, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_align(s_bt_list_hint, LV_ALIGN_TOP_MID, 0, 24);

    const int row_h = 50;
    for (size_t i = 0; i < KORVO_BT_SCAN_MAX; ++i) {
        lv_obj_t *row = lv_obj_create(s_bt_list);
        lv_obj_set_pos(row, 0, (int)i * row_h);
        lv_obj_set_size(row, BSP_LCD_H_RES - 34, row_h - 3);
        lv_obj_set_style_bg_color(row, lv_color_hex(0x202f3c), 0);
        lv_obj_set_style_bg_opa(row, LV_OPA_COVER, 0);
        lv_obj_set_style_border_width(row, 0, 0);
        lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);

        lv_obj_t *label = lv_label_create(row);
        lv_label_set_text(label, "--");
        lv_obj_set_width(label, BSP_LCD_H_RES - 190);
        lv_obj_set_style_text_color(label, lv_color_white(), 0);
        lv_obj_align(label, LV_ALIGN_LEFT_MID, 6, 0);

        lv_obj_t *act_label = NULL;
        lv_obj_t *act = make_touch_button(row, "PAIR", 150, 34, &act_label);
        lv_obj_align(act, LV_ALIGN_RIGHT_MID, -6, 0);
        lv_obj_add_event_cb(act, bt_device_cb, LV_EVENT_CLICKED, NULL);
        lv_obj_add_flag(row, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_add_event_cb(row, bt_device_cb, LV_EVENT_CLICKED, NULL);

        s_bt_device_row[i] = row;
        s_bt_device_label[i] = label;
        s_bt_device_btn[i] = act;
        s_bt_device_btn_label[i] = act_label;
        s_bt_device_mac[i][0] = 0;
        lv_obj_add_flag(row, LV_OBJ_FLAG_HIDDEN);
    }

    lv_obj_add_flag(s_bt_panel, LV_OBJ_FLAG_HIDDEN);
}

static void set_message(const char *text)
{
    if (s_message == NULL) {
        return;
    }

    bsp_display_lock(0);
    lv_label_set_text(s_message, text);
    bsp_display_unlock();
}

static void reset_face_track(void)
{
    s_track.valid = false;
    s_track.cx = 0;
    s_track.cy = 0;
    s_track.w = 0;
    s_track.h = 0;
    s_track.stable_samples = 0;
}

static void set_face_state(korvo_hmi_face_state_t state)
{
    if (s_face_state == state) {
        return;
    }

    s_face_state = state;

    switch (state) {
    case KORVO_HMI_FACE_NONE:
        set_message("POSICIONE SU ROSTRO\nEN EL RECUADRO");
        break;

    case KORVO_HMI_FACE_POSITION:
        set_message("POSICIONE SU ROSTRO\nEN EL RECUADRO");
        break;

    case KORVO_HMI_FACE_HOLD_STILL:
        set_message("MANTENGASE QUIETO");
        break;

    case KORVO_HMI_FACE_READY:
        set_message("ROSTRO LISTO");
        break;

    default:
        break;
    }
}

void korvo_hmi_init(void)
{
    lv_obj_t *screen = lv_scr_act();

    s_guide = lv_obj_create(screen);
    lv_obj_remove_style_all(s_guide);
    lv_obj_set_size(s_guide,
                    (BSP_LCD_H_RES * GUIDE_W_PERCENT) / 100,
                    (BSP_LCD_V_RES * GUIDE_H_PERCENT) / 100);
    lv_obj_center(s_guide);
    lv_obj_set_style_border_width(s_guide, 4, 0);
    lv_obj_set_style_border_color(s_guide, lv_color_white(), 0);
    lv_obj_set_style_border_opa(s_guide, LV_OPA_90, 0);
    lv_obj_set_style_radius(s_guide, 18, 0);
    lv_obj_set_style_bg_opa(s_guide, LV_OPA_TRANSP, 0);

    /*
     * Dynamic ESP-DL face overlay.
     * It is intentionally separate from the fixed portrait guide.
     */
    s_face_box = lv_obj_create(screen);
    lv_obj_remove_style_all(s_face_box);
    lv_obj_set_style_border_width(s_face_box, 2, 0);
    lv_obj_set_style_border_color(s_face_box, lv_color_white(), 0);
    lv_obj_set_style_border_opa(s_face_box, LV_OPA_COVER, 0);
    lv_obj_set_style_bg_opa(s_face_box, LV_OPA_TRANSP, 0);
    lv_obj_add_flag(s_face_box, LV_OBJ_FLAG_HIDDEN);

    s_face_center = lv_obj_create(screen);
    lv_obj_remove_style_all(s_face_center);
    lv_obj_set_size(s_face_center, 8, 8);
    lv_obj_set_style_radius(s_face_center, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_color(s_face_center, lv_color_white(), 0);
    lv_obj_set_style_bg_opa(s_face_center, LV_OPA_COVER, 0);
    lv_obj_add_flag(s_face_center, LV_OBJ_FLAG_HIDDEN);

    s_message = lv_label_create(screen);
    lv_label_set_text(s_message, "POSICIONE SU ROSTRO\nEN EL RECUADRO");
    lv_obj_set_style_text_color(s_message, lv_color_white(), 0);
    lv_obj_set_style_text_align(s_message, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_bg_color(s_message, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s_message, LV_OPA_70, 0);
    lv_obj_set_style_pad_all(s_message, 8, 0);
    lv_obj_align(s_message, LV_ALIGN_TOP_MID, 0, 6);

    /* Temporary engineering diagnostic for motion / standby calibration. */
    s_motion_diag = lv_label_create(screen);
    lv_label_set_text(s_motion_diag,
                      "MOVIMIENTO: --.-%\n"
                      "ESTADO: INICIANDO\n"
                      "INACTIVO: 0.0 / 10.0 s\n"
                      "APAGADO EN: 10.0 s");
    lv_obj_set_style_text_color(s_motion_diag, lv_color_white(), 0);
    lv_obj_set_style_bg_color(s_motion_diag, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s_motion_diag, LV_OPA_70, 0);
    lv_obj_set_style_pad_all(s_motion_diag, 5, 0);
    lv_obj_align(s_motion_diag, LV_ALIGN_TOP_LEFT, 6, 6);

    /* Compact SD status card, symmetric with the motion diagnostic. */
    s_storage_diag = lv_label_create(screen);
    lv_label_set_text(s_storage_diag,
                      "SD CARD: --\n"
                      "FS: --\n"
                      "ESTRUCTURA: --\n"
                      "USO: --\n"
                      "LIBRE: --");
    lv_obj_set_style_text_color(s_storage_diag, lv_color_white(), 0);
    lv_obj_set_style_text_align(s_storage_diag, LV_TEXT_ALIGN_LEFT, 0);
    lv_obj_set_style_bg_color(s_storage_diag, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s_storage_diag, LV_OPA_70, 0);
    lv_obj_set_style_pad_all(s_storage_diag, 5, 0);
    lv_obj_align(s_storage_diag, LV_ALIGN_TOP_RIGHT, -6, 6);

    /* Permanent integration footer. It lives below the portrait guide so
     * Gateway/Control/SIP state never covers the central camera ROI. */
    s_gateway_footer = lv_label_create(screen);
    lv_label_set_text(s_gateway_footer,
                      "LAB · GW: --   | GW ---   | CTRL BLOCK   | SIP ---");
    lv_obj_set_width(s_gateway_footer, BSP_LCD_H_RES - 12);
    lv_obj_set_style_text_color(s_gateway_footer, lv_color_white(), 0);
    lv_obj_set_style_text_align(s_gateway_footer, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_bg_color(s_gateway_footer, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s_gateway_footer, LV_OPA_80, 0);
    lv_obj_set_style_pad_all(s_gateway_footer, 5, 0);
    lv_obj_align(s_gateway_footer, LV_ALIGN_BOTTOM_MID, 0, -4);

    /* Right-edge audio volume, kept outside the central camera/face ROI.
     * This controls the PCM sent to the HFP/SCO device, so it works for both
     * WAV alarms and SIP receive audio. */
    s_volume_slider = lv_slider_create(screen);
    lv_obj_set_size(s_volume_slider, 24, 178);
    lv_obj_align(s_volume_slider, LV_ALIGN_RIGHT_MID, -8, 18);
    lv_slider_set_range(s_volume_slider, 0, 100);
    uint8_t initial_volume = korvo_bluetooth_get_output_volume();
    lv_slider_set_value(s_volume_slider, initial_volume, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(s_volume_slider, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_volume_slider, LV_OPA_60, LV_PART_MAIN);
    lv_obj_set_style_bg_color(s_volume_slider, lv_palette_main(LV_PALETTE_GREEN), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(s_volume_slider, lv_color_white(), LV_PART_KNOB);
    lv_obj_add_event_cb(s_volume_slider, volume_slider_cb, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_add_event_cb(s_volume_slider, volume_slider_cb, LV_EVENT_RELEASED, NULL);

    s_volume_label = lv_label_create(screen);
    lv_obj_set_style_text_color(s_volume_label, lv_color_white(), 0);
    lv_obj_set_style_text_align(s_volume_label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_bg_color(s_volume_label, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s_volume_label, LV_OPA_70, 0);
    lv_obj_set_style_pad_all(s_volume_label, 4, 0);
    lv_obj_align_to(s_volume_label, s_volume_slider, LV_ALIGN_OUT_TOP_MID, 0, -6);
    volume_label_update(initial_volume);

    /* Left-edge microphone gain. Same persisted setting used by Web UI and RTP TX. */
    s_mic_slider = lv_slider_create(screen);
    lv_obj_set_size(s_mic_slider, 24, 178);
    lv_obj_align(s_mic_slider, LV_ALIGN_LEFT_MID, 8, 18);
    lv_slider_set_range(s_mic_slider, 0, 100);
    uint8_t initial_mic = korvo_bluetooth_get_mic_gain();
    lv_slider_set_value(s_mic_slider, initial_mic, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(s_mic_slider, lv_color_black(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(s_mic_slider, LV_OPA_60, LV_PART_MAIN);
    lv_obj_set_style_bg_color(s_mic_slider, lv_palette_main(LV_PALETTE_GREEN), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(s_mic_slider, lv_color_white(), LV_PART_KNOB);
    lv_obj_add_event_cb(s_mic_slider, mic_slider_cb, LV_EVENT_VALUE_CHANGED, NULL);
    lv_obj_add_event_cb(s_mic_slider, mic_slider_cb, LV_EVENT_RELEASED, NULL);
    s_mic_label = lv_label_create(screen);
    lv_obj_set_style_text_color(s_mic_label, lv_color_white(), 0);
    lv_obj_set_style_text_align(s_mic_label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_bg_color(s_mic_label, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(s_mic_label, LV_OPA_70, 0);
    lv_obj_set_style_pad_all(s_mic_label, 4, 0);
    lv_obj_align_to(s_mic_label, s_mic_slider, LV_ALIGN_OUT_TOP_MID, 0, -6);
    mic_label_update(initial_mic);

    /* Bluetooth local UI. Access is by touching the existing bottom status strip.
     * No persistent PAIR button is placed over the camera image. */
    lv_obj_add_flag(s_gateway_footer, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_event_cb(s_gateway_footer, bt_open_cb, LV_EVENT_CLICKED, NULL);
    build_bluetooth_panel(screen);

    /* V1.3.19: visual screensaver removed. Camera/motion/watchdog chain remains untouched. */

    reset_face_track();
    s_face_state = KORVO_HMI_FACE_NONE;

    ESP_LOGI(TAG, "Access HMI initialized");
}

void korvo_hmi_sleep(void)
{
    /* V1.3.19: no visual screensaver. Keep this entry point because motion/camera
     * logic already depends on it; do not disturb the proven camera/watchdog chain. */
    s_awake = false;
}

void korvo_hmi_wake(void)
{
    s_awake = true;
    reset_face_track();
    s_face_state = KORVO_HMI_FACE_POSITION;
    set_message("POSICIONE SU ROSTRO\nEN EL RECUADRO");
}

void korvo_hmi_no_face(void)
{
    /*
     * Losing the face invalidates READY immediately. This is deliberately
     * separate from the 10 s LCD timeout.
     */
    reset_face_track();
    korvo_hmi_hide_face_track();

    if (s_awake) {
        set_face_state(KORVO_HMI_FACE_POSITION);
    } else {
        s_face_state = KORVO_HMI_FACE_NONE;
    }
}

void korvo_hmi_hide_face_track(void)
{
    if (s_face_box == NULL || s_face_center == NULL) {
        return;
    }

    bsp_display_lock(0);
    lv_obj_add_flag(s_face_box, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(s_face_center, LV_OBJ_FLAG_HIDDEN);
    bsp_display_unlock();
}

void korvo_hmi_track_face(const face_detection_t *face,
                          uint16_t camera_width,
                          uint16_t camera_height)
{
    if (!s_awake || face == NULL || !face->detected ||
        camera_width == 0 || camera_height == 0 ||
        s_face_box == NULL || s_face_center == NULL) {
        korvo_hmi_hide_face_track();
        return;
    }

    int x1 = face->x1;
    int y1 = face->y1;
    int x2 = face->x2;
    int y2 = face->y2;

    if (x1 < 0) x1 = 0;
    if (y1 < 0) y1 = 0;
    if (x2 >= camera_width) x2 = camera_width - 1;
    if (y2 >= camera_height) y2 = camera_height - 1;

    if (x2 <= x1 || y2 <= y1) {
        korvo_hmi_hide_face_track();
        return;
    }

    /*
     * ESP-DL coordinates are in camera-frame space.
     * Map them to the LCD canvas. The current project uses rotation=0 in
     * normal operation; this mapping follows the aspect-fit dimensions.
     */
    int display_w = BSP_LCD_H_RES;
    int display_h = BSP_LCD_V_RES;

    float camera_aspect = (float)camera_width / (float)camera_height;
    float display_aspect = (float)display_w / (float)display_h;

    int video_w;
    int video_h;
    int video_x;
    int video_y;

    if (camera_aspect > display_aspect) {
        video_w = display_w;
        video_h = (int)((float)display_w / camera_aspect);
        video_x = 0;
        video_y = (display_h - video_h) / 2;
    } else {
        video_h = display_h;
        video_w = (int)((float)display_h * camera_aspect);
        video_x = (display_w - video_w) / 2;
        video_y = 0;
    }

    int sx1 = video_x + (x1 * video_w) / camera_width;
    int sy1 = video_y + (y1 * video_h) / camera_height;
    int sx2 = video_x + (x2 * video_w) / camera_width;
    int sy2 = video_y + (y2 * video_h) / camera_height;

    int box_w = sx2 - sx1;
    int box_h = sy2 - sy1;
    int center_x = sx1 + box_w / 2;
    int center_y = sy1 + box_h / 2;

    bsp_display_lock(0);

    lv_obj_set_pos(s_face_box, sx1, sy1);
    lv_obj_set_size(s_face_box, box_w, box_h);
    lv_obj_clear_flag(s_face_box, LV_OBJ_FLAG_HIDDEN);

    lv_obj_set_pos(s_face_center, center_x - 4, center_y - 4);
    lv_obj_clear_flag(s_face_center, LV_OBJ_FLAG_HIDDEN);

    /* Keep diagnostics and instructions above the video canvas. */
    lv_obj_move_foreground(s_guide);
    lv_obj_move_foreground(s_face_box);
    lv_obj_move_foreground(s_face_center);
    lv_obj_move_foreground(s_message);
    if (s_motion_diag != NULL) {
        lv_obj_move_foreground(s_motion_diag);
    }
    if (s_storage_diag != NULL) {
        lv_obj_move_foreground(s_storage_diag);
    }
    if (s_gateway_footer != NULL && !s_bt_panel_visible) {
        lv_obj_move_foreground(s_gateway_footer);
    }
    if (s_volume_slider != NULL && !s_bt_panel_visible) {
        lv_obj_move_foreground(s_volume_slider);
    }
    if (s_volume_label != NULL && !s_bt_panel_visible) {
        lv_obj_move_foreground(s_volume_label);
    }
    if (s_mic_slider != NULL && !s_bt_panel_visible) lv_obj_move_foreground(s_mic_slider);
    if (s_mic_label != NULL && !s_bt_panel_visible) lv_obj_move_foreground(s_mic_label);
    if (s_bt_panel_visible && s_bt_panel != NULL) {
        lv_obj_move_foreground(s_bt_panel);
    }

    bsp_display_unlock();
}

void korvo_hmi_update_face(const face_detection_t *face,
                           uint16_t camera_width,
                           uint16_t camera_height)
{
    if (!s_awake || face == NULL || !face->detected ||
        camera_width == 0 || camera_height == 0) {
        return;
    }

    int face_w = face->x2 - face->x1;
    int face_h = face->y2 - face->y1;

    if (face_w <= 0 || face_h <= 0) {
        reset_face_track();
        set_face_state(KORVO_HMI_FACE_POSITION);
        return;
    }

    int face_cx = face->x1 + face_w / 2;
    int face_cy = face->y1 + face_h / 2;

    bool centered_x =
        face_cx > (int)(camera_width * FACE_CENTER_X_MIN_PERCENT / 100) &&
        face_cx < (int)(camera_width * FACE_CENTER_X_MAX_PERCENT / 100);

    bool centered_y =
        face_cy > (int)(camera_height * FACE_CENTER_Y_MIN_PERCENT / 100) &&
        face_cy < (int)(camera_height * FACE_CENTER_Y_MAX_PERCENT / 100);

    bool close_enough =
        face_w > (int)(camera_width * FACE_MIN_W_PERCENT / 100) &&
        face_h > (int)(camera_height * FACE_MIN_H_PERCENT / 100);

    int aspect_percent = (face_w * 100) / face_h;
    bool plausible_aspect =
        aspect_percent >= FACE_ASPECT_MIN_PERCENT &&
        aspect_percent <= FACE_ASPECT_MAX_PERCENT;

    /*
     * Geometry gate: an ESP-DL candidate may wake the screen, but it cannot
     * accumulate READY stability unless it looks like a usable face crop.
     */
    bool geometry_ok = centered_x && centered_y &&
                       close_enough && plausible_aspect;

    if (!geometry_ok) {
        reset_face_track();
        set_face_state(KORVO_HMI_FACE_POSITION);
        return;
    }

    bool stable = false;

    if (s_track.valid) {
        int dx = abs(face_cx - s_track.cx);
        int dy = abs(face_cy - s_track.cy);
        int dw = abs(face_w - s_track.w);
        int dh = abs(face_h - s_track.h);

        int max_dx = (int)(camera_width * STABLE_CENTER_DELTA_X_PERCENT / 100);
        int max_dy = (int)(camera_height * STABLE_CENTER_DELTA_Y_PERCENT / 100);
        int max_dw = (s_track.w * STABLE_SIZE_DELTA_PERCENT) / 100;
        int max_dh = (s_track.h * STABLE_SIZE_DELTA_PERCENT) / 100;

        if (max_dw < 1) max_dw = 1;
        if (max_dh < 1) max_dh = 1;

        stable = dx <= max_dx &&
                 dy <= max_dy &&
                 dw <= max_dw &&
                 dh <= max_dh;
    }

    if (!s_track.valid) {
        s_track.stable_samples = 1;
    } else if (stable) {
        if (s_track.stable_samples < READY_STABLE_SAMPLES) {
            s_track.stable_samples++;
        }
    } else {
        /*
         * The face is valid but moving. Start stability accumulation again.
         */
        s_track.stable_samples = 1;
    }

    s_track.valid = true;
    s_track.cx = face_cx;
    s_track.cy = face_cy;
    s_track.w = face_w;
    s_track.h = face_h;

    if (s_track.stable_samples >= READY_STABLE_SAMPLES) {
        set_face_state(KORVO_HMI_FACE_READY);
    } else {
        set_face_state(KORVO_HMI_FACE_HOLD_STILL);
    }

    ESP_LOGI(TAG,
             "FACE MATRIX geom=%d stable=%d samples=%lu/%d center=%d,%d size=%dx%d aspect=%d%%",
             geometry_ok,
             stable,
             (unsigned long)s_track.stable_samples,
             READY_STABLE_SAMPLES,
             face_cx, face_cy, face_w, face_h, aspect_percent);
}

void korvo_hmi_update_motion(uint32_t motion_percent_x10,
                             bool moving,
                             uint32_t idle_ms,
                             uint32_t sleep_ms)
{
    if (s_motion_diag == NULL) {
        return;
    }

    uint32_t pct_whole = motion_percent_x10 / 10U;
    uint32_t pct_frac = motion_percent_x10 % 10U;
    uint32_t idle_tenths = idle_ms / 100U;
    uint32_t sleep_tenths = sleep_ms / 100U;
    uint32_t remain_ms = (idle_ms >= sleep_ms) ? 0U : sleep_ms - idle_ms;
    uint32_t remain_tenths = remain_ms / 100U;

    char text[160];
    snprintf(text, sizeof(text),
             "MOVIMIENTO: %lu.%lu%%\n"
             "ESTADO: %s\n"
             "INACTIVO: %lu.%lu / %lu.%lu s\n"
             "APAGADO EN: %lu.%lu s",
             (unsigned long)pct_whole,
             (unsigned long)pct_frac,
             moving ? "MOVIMIENTO" : "SIN MOVIMIENTO",
             (unsigned long)(idle_tenths / 10U),
             (unsigned long)(idle_tenths % 10U),
             (unsigned long)(sleep_tenths / 10U),
             (unsigned long)(sleep_tenths % 10U),
             (unsigned long)(remain_tenths / 10U),
             (unsigned long)(remain_tenths % 10U));

    bsp_display_lock(0);
    lv_label_set_text(s_motion_diag, text);
    if (!s_bt_panel_visible) lv_obj_move_foreground(s_motion_diag);
    if (s_bt_panel_visible && s_bt_panel) lv_obj_move_foreground(s_bt_panel);
    bsp_display_unlock();

}


void korvo_hmi_update_storage(bool sd_ok,
                              bool fs_ok,
                              bool structure_ok,
                              int storage_state,
                              uint64_t used_bytes,
                              uint64_t free_bytes)
{
    if (s_storage_diag == NULL) {
        return;
    }

    char text[224];

    /* korvo_storage_state_t: ERROR=0 READY=1 INITIALIZING=2 REPAIRING=3 FOREIGN=4 */
    if (storage_state == 4) {
        snprintf(text, sizeof(text),
                 "SD CARD: OK\n"
                 "FS: FAT32 OK\n"
                 "ESTRUCTURA: AJENA\n"
                 "TARJETA NO APTA\n"
                 "PARA INICIALIZAR");
    } else if (storage_state == 2) {
        snprintf(text, sizeof(text),
                 "SD CARD: OK\n"
                 "FS: FAT32 OK\n"
                 "INICIALIZANDO ESTRUCTURA...");
    } else if (storage_state == 3) {
        snprintf(text, sizeof(text),
                 "SD CARD: OK\n"
                 "FS: FAT32 OK\n"
                 "CORRIGIENDO ESTRUCTURA...");
    } else if (sd_ok && fs_ok) {
        const double gib = 1024.0 * 1024.0 * 1024.0;
        snprintf(text, sizeof(text),
                 "SD CARD: OK\n"
                 "FS: FAT32 OK\n"
                 "ESTRUCTURA: %s\n"
                 "USO: %.1f GB\n"
                 "LIBRE: %.1f GB",
                 structure_ok ? "OK" : "ERROR",
                 (double)used_bytes / gib,
                 (double)free_bytes / gib);
    } else if (sd_ok) {
        snprintf(text, sizeof(text),
                 "SD CARD: OK\n"
                 "FS: ERROR\n"
                 "ESTRUCTURA: --\n"
                 "USO: --\n"
                 "LIBRE: --");
    } else {
        snprintf(text, sizeof(text),
                 "SD CARD: ERROR\n"
                 "FS: --\n"
                 "ESTRUCTURA: --\n"
                 "USO: --\n"
                 "LIBRE: --");
    }

    bsp_display_lock(0);
    lv_label_set_text(s_storage_diag, text);
    if (!s_bt_panel_visible) lv_obj_move_foreground(s_storage_diag);
    if (s_bt_panel_visible && s_bt_panel) lv_obj_move_foreground(s_bt_panel);
    bsp_display_unlock();
}

void korvo_hmi_update_bluetooth(const korvo_bluetooth_status_t *bt)
{
    if (!bt) return;

    /* The detailed Bluetooth screen is hidden during normal camera operation.
     * Do not churn LVGL labels/rows every 500 ms while it is hidden; the footer
     * is updated separately and the panel refreshes immediately after opening. */
    if (!s_bt_panel_visible) return;

    char status[256];
    const char *peer_name = bt->peer_name[0] ? bt->peer_name :
                            (bt->peer_mac[0] ? bt->peer_mac : "--");
    const char *power = bt->enabled ? "ENCENDIDO" : "APAGADO";
    const char *pair = bt->paired ? "PAREADO" :
                       (bt->peer_mac[0] ? "PAIR EN PROCESO" : "SIN PAIR");
    const char *audio = bt->audio_connected ? "CONECTADO" : "DESCONECTADO";

    snprintf(status, sizeof(status),
             "BLUETOOTH: %s\nPAIR: %s - %.64s\nHFP: %s   AUDIO: %s",
             power, pair, peer_name,
             bt->slc_connected ? "CONECTADO" : (bt->connecting ? "CONECTANDO" : "DESCONECTADO"),
             audio);

    bsp_display_lock(0);
    if (s_volume_slider) {
        uint8_t volume = korvo_bluetooth_get_output_volume();
        lv_slider_set_value(s_volume_slider, volume, LV_ANIM_OFF);
        volume_label_update(volume);
    }
    if (s_mic_slider) {
        uint8_t mic = korvo_bluetooth_get_mic_gain();
        lv_slider_set_value(s_mic_slider, mic, LV_ANIM_OFF);
        mic_label_update(mic);
    }
    if (s_bt_status_label) lv_label_set_text(s_bt_status_label, status);
    if (s_bt_power_btn_label) lv_label_set_text(s_bt_power_btn_label, bt->enabled ? "APAGAR" : "ENCENDER");
    if (s_bt_scan_btn_label) lv_label_set_text(s_bt_scan_btn_label, bt->scanning ? "ESCANEANDO..." : "SCAN");
    if (s_bt_link_btn_label) {
        lv_label_set_text(s_bt_link_btn_label,
                          bt->slc_connected ? "DESCONECTAR" :
                          (bt->connecting ? "CONECTANDO..." : "CONECTAR"));
    }
    if (s_bt_error_label) {
        if (bt->last_error[0]) lv_label_set_text(s_bt_error_label, bt->last_error);
        else if (bt->scanning) lv_label_set_text(s_bt_error_label, "Buscando dispositivos...");
        else lv_label_set_text(s_bt_error_label, "--");
    }
    if (s_bt_list_hint) {
        if (bt->device_count == 0) {
            lv_label_set_text(s_bt_list_hint, bt->scanning ? "Buscando dispositivos Bluetooth..." :
                              "Pulse SCAN y ponga el dispositivo en modo pairing.");
            lv_obj_clear_flag(s_bt_list_hint, LV_OBJ_FLAG_HIDDEN);
        } else {
            lv_obj_add_flag(s_bt_list_hint, LV_OBJ_FLAG_HIDDEN);
        }
    }

    for (size_t i = 0; i < KORVO_BT_SCAN_MAX; ++i) {
        if (!s_bt_device_row[i]) continue;
        if (i < bt->device_count) {
            const korvo_bluetooth_device_t *d = &bt->devices[i];
            char row_text[160];
            snprintf(row_text, sizeof(row_text), "%.63s\n%.17s   RSSI %d dBm",
                     d->name[0] ? d->name : "--", d->mac, d->rssi);
            lv_label_set_text(s_bt_device_label[i], row_text);

            size_t n = strlen(d->mac);
            if (n >= sizeof(s_bt_device_mac[i])) n = sizeof(s_bt_device_mac[i]) - 1;
            memcpy(s_bt_device_mac[i], d->mac, n);
            s_bt_device_mac[i][n] = 0;

            bool same_peer = bt->peer_mac[0] && !strcmp(bt->peer_mac, d->mac);
            bool connected = bt->slc_connected && same_peer;
            bool connecting = bt->connecting && same_peer;
            bool paired = bt->paired && same_peer;
            lv_label_set_text(s_bt_device_btn_label[i],
                              connected ? "CONECTADO" :
                              (connecting ? "CONECTANDO..." :
                               (paired ? "CONECTAR" : "PAIR / CONECTAR")));
            if (connected || connecting) lv_obj_clear_flag(s_bt_device_btn[i], LV_OBJ_FLAG_CLICKABLE);
            else lv_obj_add_flag(s_bt_device_btn[i], LV_OBJ_FLAG_CLICKABLE);
            lv_obj_clear_flag(s_bt_device_row[i], LV_OBJ_FLAG_HIDDEN);
        } else {
            s_bt_device_mac[i][0] = 0;
            lv_obj_add_flag(s_bt_device_row[i], LV_OBJ_FLAG_HIDDEN);
        }
    }

    if (s_bt_panel_visible && s_bt_panel) lv_obj_move_foreground(s_bt_panel);
    bsp_display_unlock();
}

void korvo_hmi_update_gateway_status(const char *room,
                                     const char *gateway_name,
                                     bool gateway_ok,
                                     bool control_ok,
                                     bool sip_registered,
                                     const char *sip_state,
                                     bool bt_enabled,
                                     bool bt_paired,
                                     bool bt_connected,
                                     const char *bt_peer)
{
    if (s_gateway_footer == NULL) {
        return;
    }

    char text[320];
    const char *gw = (gateway_name && gateway_name[0]) ? gateway_name : "--";
    const char *rm = (room && room[0]) ? room : "--";
    const char *sip = (sip_state && sip_state[0]) ? sip_state : "---";
    const char *bt = !bt_enabled ? "OFF" : (bt_connected ? "CON" : (bt_paired ? "PAIR" : "ON"));
    const char *peer = (bt_peer && bt_peer[0]) ? bt_peer : "";

    if (bt_paired && peer[0]) {
        snprintf(text, sizeof(text),
                 "%.31s · %.31s | GW %s | CTRL %s | SIP %s%.15s | BT %s:%.12s",
                 rm, gw,
                 gateway_ok ? "OK" : "---",
                 control_ok ? "OK" : "BLOCK",
                 sip_registered ? "REG/" : "", sip,
                 bt, peer);
    } else {
        snprintf(text, sizeof(text),
                 "%.31s · %.31s | GW %s | CTRL %s | SIP %s%.15s | BT %s",
                 rm, gw,
                 gateway_ok ? "OK" : "---",
                 control_ok ? "OK" : "BLOCK",
                 sip_registered ? "REG/" : "", sip,
                 bt);
    }

    bsp_display_lock(0);
    lv_label_set_text(s_gateway_footer, text);
    lv_obj_set_style_text_color(
        s_gateway_footer,
        control_ok ? lv_palette_main(LV_PALETTE_GREEN) :
        (gateway_ok ? lv_palette_main(LV_PALETTE_ORANGE) : lv_color_white()),
        0);
    if (!s_bt_panel_visible) lv_obj_move_foreground(s_gateway_footer);
    if (s_bt_panel_visible && s_bt_panel) lv_obj_move_foreground(s_bt_panel);
    bsp_display_unlock();
}

korvo_hmi_face_state_t korvo_hmi_face_state(void)
{
    return s_face_state;
}
